package EmployeeActivities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Connect.JDBCcon;
import MBuActivities.Alloted;

/**
 * Servlet implementation class Empdetails
 */
public class Empdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Empdetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		JDBCcon conn=new JDBCcon();
		Connection got=conn.getConnect();
		int count=0;
		ArrayList<Alloted> fetch=new ArrayList<Alloted>();

		try {
			int eid=Integer.parseInt(session.getAttribute("empid").toString());
			Statement st=got.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs1=st.executeQuery("select * from alloted_employee where emp_id="+eid);
			
			if(!rs1.next())
			{
				response.sendRedirect("empworkstatus2.jsp");
			}
			
			else
			{
				rs1.beforeFirst();
				while(rs1.next())
				{
					count++;
				}
				rs1.beforeFirst();

				//int size=rs1.getRow();
				System.out.println(count);

				//System.out.println(size);
				Alloted a[]=new Alloted[count];

				for (int i = 0; i < a.length; i++)
				{
					rs1.next();
					a[i]=new Alloted(rs1.getString(1), rs1.getString(2), rs1.getInt(3), rs1.getString(4), rs1.getString(5), rs1.getString(6));
					fetch.add(a[i]);
					System.out.println("added");
					System.out.println(a[i]);
				}
				rs1.close();
				session.setAttribute("fetchlist", fetch);
				response.sendRedirect("empworkstatus1.jsp");

			}

		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
