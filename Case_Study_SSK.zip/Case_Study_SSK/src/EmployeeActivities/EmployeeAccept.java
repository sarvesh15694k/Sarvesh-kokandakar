package EmployeeActivities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Connect.JDBCcon;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class EmployeeAccept
 */
public class EmployeeAccept extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeAccept() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		JDBCcon conn=new JDBCcon();
		Connection got=conn.getConnect();
		String choice=request.getParameter("status");
		HttpSession session=request.getSession(false);
		String loginname=session.getAttribute("name").toString();
		System.out.println(loginname);
		
		
		try {
			Statement st=got.createStatement();
			ResultSet rs=st.executeQuery("select EMP_ID from employee where EMP_name='"+loginname+"'");
			int id=0;
			while(rs.next())
			{
				id=rs.getInt(1);
			}
			rs.close();
			
			PreparedStatement pst=got.prepareStatement("update employee set offerstatus=? where emp_id=?");
			pst.setString(1, choice);
			pst.setInt(2, id);
			pst.executeUpdate();
			System.out.println("Choice modified for"+loginname);
			
			response.sendRedirect("emphomeconfirm.jsp");
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
