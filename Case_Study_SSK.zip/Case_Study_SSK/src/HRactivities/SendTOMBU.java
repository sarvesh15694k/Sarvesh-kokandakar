package HRactivities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Connect.JDBCcon;

/**
 * Servlet implementation class SendTOMBU
 */
public class SendTOMBU extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendTOMBU() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession();
		
		String name=request.getParameter("empnametombu");
	
		int id=Integer.parseInt(request.getParameter("empidtombu"));
		
		JDBCcon conn=new JDBCcon();
		Connection got=conn.getConnect();
		String doj=null;
		try {
			
			Statement st1=got.createStatement();
			Statement st=got.createStatement();
			ResultSet rs=st.executeQuery("select doj, skill from employee where emp_id="+id);
			rs.next();
			doj=rs.getString(1);
			String skill=rs.getString(2);
			rs.close();
			
			st1.executeUpdate("update employee set department='Microsoft' where emp_id="+id);
			PreparedStatement pst=got.prepareStatement("insert into alloted_employee values(?,?,?,?,?,?)");
			pst.setString(1, name);
			pst.setString(2, doj);
			pst.setInt(3, id);
			pst.setString(4, "MBU");
			pst.setString(5, "unassigned");
			pst.setString(6, skill);
			int i=pst.executeUpdate();
			
			
			session.setAttribute("busentname", name);
			session.setAttribute("busentid", id);
			response.sendRedirect("sentToBU.jsp");
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
