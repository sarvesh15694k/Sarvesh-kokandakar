package HRactivities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.text.html.HTML;

import Connect.JDBCcon;

/**
 * Servlet implementation class fetchAcceptance
 */
public class fetchAcceptanceEMP extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public fetchAcceptanceEMP() {
        super();
        // TODO Auto-generated constructor stub
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession();
		JDBCcon conn=new JDBCcon();
		Connection got=conn.getConnect();
		try {
			Statement st=got.createStatement();
			ResultSet rs=st.executeQuery("select EMP_id, EMP_name, offerstatus from employee where offerstatus='accepted'");
			session.setAttribute("fetchedstatus", rs);
			response.sendRedirect("fetchedDetails.jsp");
			
			
			/*
			while(rs.next())
			{	
				int id=rs.getInt(1);
				String ename=rs.getString(2);
				String ostatus=rs.getString(3);
				
				
				
			}*/
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
