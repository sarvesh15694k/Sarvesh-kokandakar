package MBuActivities;

public class Alloted {

	
	String empname;
	String dojoin;
	int emp_id;
	String bu_id;
	String sys_id;
	String skill;
	public Alloted(String empname, String dojoin, int emp_id, String bu_id,
			String sys_id, String skill) {
		super();
		this.empname = empname;
		this.dojoin = dojoin;
		this.emp_id = emp_id;
		this.bu_id = bu_id;
		this.sys_id = sys_id;
		this.skill=skill;
	}
	@Override
	public String toString() {
		return "Employee Name=" + empname + ", Joining date=" + dojoin
				+ ", ID=" + emp_id + ", BU_id=" + bu_id + ", System ID="
				+ sys_id +",   Skilled in "+skill;
	}
	
	
	
}

