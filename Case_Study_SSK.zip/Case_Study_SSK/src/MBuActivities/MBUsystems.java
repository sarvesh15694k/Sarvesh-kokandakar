package MBuActivities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Connect.JDBCcon;

/**
 * Servlet implementation class MBUsystems
 */
public class MBUsystems extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MBUsystems() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session=request.getSession();
		JDBCcon conn=new JDBCcon();
		Connection got=conn.getConnect();
		int count=0;
		ArrayList<Alloted> fetch=new ArrayList<Alloted>();
		int count2=0;
		ArrayList<Systems> fetch1=new ArrayList<Systems>();
		
	
			
			Statement st2;
			try {
				st2 = got.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs2=st2.executeQuery("select * from systems where status='AVL'");
				
				while(rs2.next())
				{
					count2++;
				}
				rs2.beforeFirst();
				
				//int size=rs1.getRow();
				System.out.println(count2);
				
				//System.out.println(size);
				Systems s[]=new Systems[count2];
				
				for (int i = 0; i < s.length; i++) {
					rs2.next();
					
					s[i]=new Systems(rs2.getInt(1), rs2.getString(2));
					fetch1.add(s[i]);
					System.out.println("added");
					System.out.println(s[i]);
				}
				rs2.close();
				session.setAttribute("fetchlist1", fetch1);
				response.sendRedirect("MBUdisplay1.jsp");
			} 
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
