package MBuActivities;

public class Systems {

	int id;
	String status;
	public Systems(int id, String status) {
		super();
		this.id = id;
		this.status = status;
	}
	@Override
	public String toString() {
		return "System available [id=" + id + ", status=" + status + "]";
	}
	
	
}
