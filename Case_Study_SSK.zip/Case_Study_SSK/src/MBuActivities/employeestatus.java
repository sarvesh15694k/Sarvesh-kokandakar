package MBuActivities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Connect.JDBCcon;

/**
 * Servlet implementation class employeestatus
 */
public class employeestatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public employeestatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String choice=request.getParameter("choice");
		String name=request.getParameter("empname");
		String eid=request.getParameter("empid");
		String sysid=request.getParameter("sysid");

		JDBCcon conn=new JDBCcon();
		Connection got=conn.getConnect();
		if(choice.equalsIgnoreCase("allot"))
		{
			try {
				Statement st=got.createStatement();
				int i=st.executeUpdate("update alloted_employee set system_id="+sysid+" where emp_id="+eid);
				int o=st.executeUpdate("update systems set status='NAVL' where system_id="+sysid);
				
				response.sendRedirect("systemalloted.jsp");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else
		{
			try {
				Statement st=got.createStatement();
				int i=st.executeUpdate("delete from alloted_employee where emp_id="+eid);
				int o=st.executeUpdate("update employee set department='NA' where emp_id="+eid);
				int m=st.executeUpdate("update systems set status='AVL' where system_id="+sysid);
				response.sendRedirect("backtopool.jsp");
				System.out.println("Data modified in alloted_employee and employee table");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
