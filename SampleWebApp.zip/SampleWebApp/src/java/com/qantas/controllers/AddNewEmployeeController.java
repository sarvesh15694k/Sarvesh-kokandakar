

package com.qantas.controllers;

import com.qantas.beans.Employee;
import com.qantas.services.EmployeeService;
import com.qantas.servicesfactory.ServiceFactory;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USHA KIRAN
 */
public class AddNewEmployeeController extends HttpServlet {
   
    public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
       String employeeId = request.getParameter("employeeIdentification");
       String employeeName = request.getParameter("employeeName");
       int basicSalary = Integer.parseInt(request.getParameter("basicSalary"));

       Employee employee = new Employee( );

       employee.setEmployeeIdentification(employeeId);
       employee.setEmployeeName(employeeName);
       employee.setBasicSalary(basicSalary);
       
       EmployeeService employeeService = ServiceFactory.getEmployeeService();
       
       try{
       employeeService.addNewEmployee(employee);
       }
       catch(ClassNotFoundException ce ){
           ce.printStackTrace();
           // append message to log file
       }
       catch(SQLException se){
           se.printStackTrace( );
           // append message to log file
       }
       String outputPage = getServletContext( ).getInitParameter("outputPage");
       RequestDispatcher rd = request.getRequestDispatcher(outputPage);
       rd.forward(request, response);

       
    } 


}
