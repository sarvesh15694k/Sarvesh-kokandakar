/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.daofactory;

import com.qantas.daoimplementations.EmployeeDaoImplementation;
import com.qantas.daoimplementations.LoginDaoImplementation;
import com.qantas.daointerfaces.EmployeeDao;
import com.qantas.daointerfaces.LoginDao;

/**
 *
 * @author USHA KIRAN
 */
public class DaoFactory {

    private static EmployeeDao empDao= null;
    private static LoginDao loginDao=null;

    public static EmployeeDao getEmployeeDao( ){
        if(empDao==null){
            empDao=new EmployeeDaoImplementation( );

        }
        else{
            return empDao;
        }
        return empDao;
    }

    public static LoginDao getLoginDao( ){
        if(loginDao==null){
            loginDao=new LoginDaoImplementation( );
        }
        else{
            return loginDao;
        }
        return loginDao;

    }

}
