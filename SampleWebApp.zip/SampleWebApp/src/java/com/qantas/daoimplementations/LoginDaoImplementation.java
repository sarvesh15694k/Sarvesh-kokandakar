/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.daoimplementations;

import com.qantas.beans.Login;
import com.qantas.daointerfaces.LoginDao;
import com.qantas.utilities.DatabaseConnectionUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author USHA KIRAN
 */
public class LoginDaoImplementation  implements LoginDao{

    public String validateUser( Login login) throws ClassNotFoundException, SQLException{
        String role = "";
        Connection con = DatabaseConnectionUtility.getConnection();
        PreparedStatement psmt = con.prepareStatement("select role from login where id=? and password=?");
        psmt.setString(1, login.getUserName());
        psmt.setString(2, login.getPassword());
        ResultSet rs = psmt.executeQuery();
        if(rs.next()){
            role=rs.getString("role");
        }
        else{
            role = "invalid";
        }
        return role;
    }

}
