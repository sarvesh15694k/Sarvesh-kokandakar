/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.daointerfaces;

import com.qantas.beans.Employee;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author USHA KIRAN
 */
public interface EmployeeDao {
    public abstract List getAllEmployeeDetails( ) throws ClassNotFoundException, SQLException;
    public abstract void addNewEmployee(Employee employee ) throws ClassNotFoundException, SQLException;

}
