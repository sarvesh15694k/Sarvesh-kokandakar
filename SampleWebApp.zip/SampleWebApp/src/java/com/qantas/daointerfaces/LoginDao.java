/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.daointerfaces;

import com.qantas.beans.Login;
import java.sql.SQLException;

/**
 *
 * @author USHA KIRAN
 */
public interface LoginDao {

    public abstract String validateUser(Login login ) throws ClassNotFoundException, SQLException;

}
