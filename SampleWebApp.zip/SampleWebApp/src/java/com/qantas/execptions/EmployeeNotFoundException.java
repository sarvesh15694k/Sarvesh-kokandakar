/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.execptions;

/**
 *
 * @author USHA KIRAN
 */
public class EmployeeNotFoundException extends Exception{

    public String toString( ){
        return "employee not found exception occurred";
    }

}
