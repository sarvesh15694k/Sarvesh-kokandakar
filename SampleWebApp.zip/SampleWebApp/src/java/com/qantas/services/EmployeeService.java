
package com.qantas.services;

import com.qantas.beans.Employee;
import com.qantas.daofactory.DaoFactory;
import com.qantas.daointerfaces.EmployeeDao;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author USHA KIRAN
 */
public class EmployeeService {

    public List getAllEmployeeDetails( ) throws ClassNotFoundException, SQLException{
        EmployeeDao employeeDao =DaoFactory.getEmployeeDao();
        return employeeDao.getAllEmployeeDetails();
    }

    public void addNewEmployee(Employee employee) throws ClassNotFoundException, SQLException{
        EmployeeDao employeeDao =DaoFactory.getEmployeeDao();
        employeeDao.addNewEmployee(employee);

    }

}
