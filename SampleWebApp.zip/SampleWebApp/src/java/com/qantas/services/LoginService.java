/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.services;

import com.qantas.beans.Login;
import com.qantas.daofactory.DaoFactory;
import com.qantas.daointerfaces.LoginDao;
import java.sql.SQLException;

/**
 *
 * @author USHA KIRAN
 */
public class LoginService {

    public String validateUser(Login login) throws ClassNotFoundException, SQLException{
        LoginDao loginDao = DaoFactory.getLoginDao();
        return loginDao.validateUser(login);
    }

}
